<?php
define("NUMBER_OF_ORDERS", 4);
define("APP_DEVELOPER", "Mikhail Senatorov");
define("APP_ID", 300407626);
define("MIN_AMOUNT", 0);
define("MAX_AMOUNT", 10);
define("TAX_RATE", 0.12);

$itemPrice = [30, 30, 40];
$discountThreshold = ['0'=> 0, '200'=> 0.05, '300'=>0.1, '500'=>0.15, '700'=>0.25];